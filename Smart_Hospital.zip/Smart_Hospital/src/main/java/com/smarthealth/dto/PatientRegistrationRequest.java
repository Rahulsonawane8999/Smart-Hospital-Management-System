package com.smarthealth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PatientRegistrationRequest {
    @NotBlank
    private String fullName;
    @Email
    @NotBlank
    private String email;
    @NotBlank
    private String password;
    private String gender;
    private Integer age;
    private String bloodGroup;
}

@Data
public class DoctorCreateRequest {
    @NotBlank
    private String fullName;
    @Email
    @NotBlank
    private String email;
    @NotBlank
    private String password;
    @NotBlank
    private String specialization;
    private String licenseNumber;
}

@Data
public class AssignDoctorRequest {
    @NotNull
    private Long patientId;
    @NotNull
    private Long doctorId;
}

@Data
public class AppointmentCreateRequest {
    @NotNull
    private Long doctorId;
    @NotNull
    private Long patientId;
    @NotNull
    private LocalDateTime appointmentTime;
    private String notes;
}

@Data
public class PrescriptionCreateRequest {
    @NotNull
    private Long doctorId;
    @NotNull
    private Long patientId;
    private String diagnosis;
    private String medicines;
    private String tests;
}


