package com.smarthealth.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class LoginRequest {
    @Email
    @NotBlank
    private String email;

    @NotBlank
    private String password;
}

@Data
class RegisterRequest {
    @NotBlank
    @Size(max = 100)
    private String fullName;
    @Email
    @NotBlank
    private String email;
    @NotBlank
    private String password;
    @NotBlank
    private String role; // ADMIN/DOCTOR/PATIENT (Admin creation only for seed or via Admin)
}

@Data
class AuthResponse {
    private String token;
    private String role;
}


