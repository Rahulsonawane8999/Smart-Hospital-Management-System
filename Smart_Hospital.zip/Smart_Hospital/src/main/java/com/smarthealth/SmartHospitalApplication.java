package com.smarthealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartHospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartHospitalApplication.class, args);
	}

}
