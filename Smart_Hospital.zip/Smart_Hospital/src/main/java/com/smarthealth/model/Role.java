package com.smarthealth.model;

public enum Role {
    ADMIN,
    DOCTOR,
    PATIENT
}


