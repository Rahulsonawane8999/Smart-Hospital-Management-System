package com.smarthealth.config;

import com.smarthealth.model.Role;
import com.smarthealth.model.User;
import com.smarthealth.repository.UserRepository;
import com.smarthealth.service.AuthService;
import com.smarthealth.service.DoctorService;
import com.smarthealth.service.PatientService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StartupDataLoader {

    @Bean
    CommandLineRunner initData(UserRepository userRepository, AuthService authService, DoctorService doctorService, PatientService patientService) {
        return args -> {
            if (userRepository.countByRole(Role.ADMIN) == 0) {
                authService.createUser("Admin User", "admin@smarthealth.com", "admin123", Role.ADMIN);
            }
            if (userRepository.countByRole(Role.DOCTOR) == 0) {
                doctorService.createDoctor("Dr. Alice", "alice@hospital.com", "password", "Cardiology", "LIC123");
                doctorService.createDoctor("Dr. Bob", "bob@hospital.com", "password", "Neurology", "LIC456");
            }
            if (userRepository.countByRole(Role.PATIENT) == 0) {
                patientService.registerPatient("John Doe", "john@example.com", "password", "Male", 30, "O+");
                patientService.registerPatient("Jane Roe", "jane@example.com", "password", "Female", 28, "A-");
            }
        };
    }
}


