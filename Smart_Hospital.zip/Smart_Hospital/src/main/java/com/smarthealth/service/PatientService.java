package com.smarthealth.service;

import com.smarthealth.model.Doctor;
import com.smarthealth.model.Patient;
import com.smarthealth.model.Role;
import com.smarthealth.model.User;
import com.smarthealth.repository.DoctorRepository;
import com.smarthealth.repository.PatientRepository;
import com.smarthealth.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final AuthService authService;
    private final UserRepository userRepository;

    public PatientService(PatientRepository patientRepository, DoctorRepository doctorRepository, AuthService authService, UserRepository userRepository) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.authService = authService;
        this.userRepository = userRepository;
    }

    public Patient registerPatient(String fullName, String email, String password, String gender, Integer age, String bloodGroup) {
        User user = authService.createUser(fullName, email, password, Role.PATIENT);
        Patient patient = new Patient();
        patient.setUser(user);
        patient.setGender(gender);
        patient.setAge(age);
        patient.setBloodGroup(bloodGroup);
        patient.setApproved(false);
        return patientRepository.save(patient);
    }

    public List<Patient> listAll() { return patientRepository.findAll(); }
    public List<Patient> listPendingApproval() { return patientRepository.findByApproved(false); }
    public Patient getById(Long id) { return patientRepository.findById(id).orElseThrow(); }

    public Patient approvePatient(Long id) {
        Patient p = getById(id);
        p.setApproved(true);
        return patientRepository.save(p);
    }

    public Patient assignDoctor(Long patientId, Long doctorId) {
        Patient p = getById(patientId);
        Doctor d = doctorRepository.findById(doctorId).orElseThrow();
        p.setAssignedDoctor(d);
        return patientRepository.save(p);
    }

    public void deletePatient(Long id) {
        Patient p = getById(id);
        Long userId = p.getUser().getId();
        patientRepository.deleteById(id);
        userRepository.deleteById(userId);
    }
}


