package com.smarthealth.service;

import com.smarthealth.model.Doctor;
import com.smarthealth.model.Role;
import com.smarthealth.model.User;
import com.smarthealth.repository.DoctorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {
    private final DoctorRepository doctorRepository;
    private final AuthService authService;

    public DoctorService(DoctorRepository doctorRepository, AuthService authService) {
        this.doctorRepository = doctorRepository;
        this.authService = authService;
    }

    public Doctor createDoctor(String fullName, String email, String password, String specialization, String licenseNumber) {
        User user = authService.createUser(fullName, email, password, Role.DOCTOR);
        Doctor doctor = new Doctor();
        doctor.setUser(user);
        doctor.setSpecialization(specialization);
        doctor.setLicenseNumber(licenseNumber);
        return doctorRepository.save(doctor);
    }

    public List<Doctor> findAll() { return doctorRepository.findAll(); }

    public Doctor getById(Long id) { return doctorRepository.findById(id).orElseThrow(); }

    public Doctor updateDoctor(Long id, String specialization, String licenseNumber, String fullName) {
        Doctor doctor = getById(id);
        if (specialization != null) doctor.setSpecialization(specialization);
        if (licenseNumber != null) doctor.setLicenseNumber(licenseNumber);
        if (fullName != null) doctor.getUser().setFullName(fullName);
        return doctorRepository.save(doctor);
    }

    public void deleteDoctor(Long id) { doctorRepository.deleteById(id); }
}


