package com.smarthealth.service;

import com.smarthealth.model.Doctor;
import com.smarthealth.model.Patient;
import com.smarthealth.model.Prescription;
import com.smarthealth.repository.DoctorRepository;
import com.smarthealth.repository.PatientRepository;
import com.smarthealth.repository.PrescriptionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrescriptionService {
    private final PrescriptionRepository prescriptionRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;

    public PrescriptionService(PrescriptionRepository prescriptionRepository, DoctorRepository doctorRepository, PatientRepository patientRepository) {
        this.prescriptionRepository = prescriptionRepository;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
    }

    public Prescription create(Long doctorId, Long patientId, String diagnosis, String medicines, String tests) {
        Doctor d = doctorRepository.findById(doctorId).orElseThrow();
        Patient p = patientRepository.findById(patientId).orElseThrow();
        Prescription pr = new Prescription();
        pr.setDoctor(d);
        pr.setPatient(p);
        pr.setDiagnosis(diagnosis);
        pr.setMedicines(medicines);
        pr.setTests(tests);
        return prescriptionRepository.save(pr);
    }

    public List<Prescription> forDoctor(Long doctorId) {
        Doctor d = doctorRepository.findById(doctorId).orElseThrow();
        return prescriptionRepository.findByDoctor(d);
    }
    public List<Prescription> forPatient(Long patientId) {
        Patient p = patientRepository.findById(patientId).orElseThrow();
        return prescriptionRepository.findByPatient(p);
    }
}


