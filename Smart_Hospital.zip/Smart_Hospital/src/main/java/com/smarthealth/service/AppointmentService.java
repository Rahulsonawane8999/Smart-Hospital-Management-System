package com.smarthealth.service;

import com.smarthealth.model.Appointment;
import com.smarthealth.model.Doctor;
import com.smarthealth.model.Patient;
import com.smarthealth.repository.AppointmentRepository;
import com.smarthealth.repository.DoctorRepository;
import com.smarthealth.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {
    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;

    public AppointmentService(AppointmentRepository appointmentRepository, DoctorRepository doctorRepository, PatientRepository patientRepository) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
    }

    public Appointment create(Long doctorId, Long patientId, LocalDateTime time, String notes) {
        Doctor d = doctorRepository.findById(doctorId).orElseThrow();
        Patient p = patientRepository.findById(patientId).orElseThrow();
        Appointment a = new Appointment();
        a.setDoctor(d);
        a.setPatient(p);
        a.setAppointmentTime(time);
        a.setNotes(notes);
        return appointmentRepository.save(a);
    }

    public List<Appointment> forDoctor(Long doctorId) {
        Doctor d = doctorRepository.findById(doctorId).orElseThrow();
        return appointmentRepository.findByDoctor(d);
    }
    public List<Appointment> forPatient(Long patientId) {
        Patient p = patientRepository.findById(patientId).orElseThrow();
        return appointmentRepository.findByPatient(p);
    }

    public void delete(Long id) { appointmentRepository.deleteById(id); }
}


