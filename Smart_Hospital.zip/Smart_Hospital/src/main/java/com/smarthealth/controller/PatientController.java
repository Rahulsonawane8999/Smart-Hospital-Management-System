package com.smarthealth.controller;

import com.smarthealth.dto.AppointmentCreateRequest;
import com.smarthealth.dto.PatientRegistrationRequest;
import com.smarthealth.model.Appointment;
import com.smarthealth.model.Patient;
import com.smarthealth.service.AppointmentService;
import com.smarthealth.service.PatientService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;
    private final AppointmentService appointmentService;

    public PatientController(PatientService patientService, AppointmentService appointmentService) {
        this.patientService = patientService;
        this.appointmentService = appointmentService;
    }

    @PostMapping("/register")
    public ResponseEntity<Patient> register(@Valid @RequestBody PatientRegistrationRequest req) {
        Patient p = patientService.registerPatient(req.getFullName(), req.getEmail(), req.getPassword(), req.getGender(), req.getAge(), req.getBloodGroup());
        return ResponseEntity.ok(p);
    }

    @PreAuthorize("hasRole('PATIENT')")
    @PostMapping("/appointments")
    public ResponseEntity<Appointment> createAppointment(@Valid @RequestBody AppointmentCreateRequest req) {
        return ResponseEntity.ok(appointmentService.create(req.getDoctorId(), req.getPatientId(), req.getAppointmentTime(), req.getNotes()));
    }

    @PreAuthorize("hasRole('PATIENT')")
    @GetMapping("/{id}")
    public ResponseEntity<Patient> getProfile(@PathVariable Long id) {
        return ResponseEntity.ok(patientService.getById(id));
    }

    @PreAuthorize("hasRole('PATIENT')")
    @GetMapping("/{id}/appointments")
    public ResponseEntity<List<Appointment>> myAppointments(@PathVariable Long id) {
        return ResponseEntity.ok(appointmentService.forPatient(id));
    }
}


