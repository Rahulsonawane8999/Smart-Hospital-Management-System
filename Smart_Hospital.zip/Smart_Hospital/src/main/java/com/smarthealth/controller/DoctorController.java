package com.smarthealth.controller;

import com.smarthealth.dto.PrescriptionCreateRequest;
import com.smarthealth.model.Appointment;
import com.smarthealth.model.Prescription;
import com.smarthealth.service.AppointmentService;
import com.smarthealth.service.PrescriptionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
@PreAuthorize("hasRole('DOCTOR')")
public class DoctorController {

    private final AppointmentService appointmentService;
    private final PrescriptionService prescriptionService;

    public DoctorController(AppointmentService appointmentService, PrescriptionService prescriptionService) {
        this.appointmentService = appointmentService;
        this.prescriptionService = prescriptionService;
    }

    @GetMapping("/{id}/appointments")
    public ResponseEntity<List<Appointment>> myAppointments(@PathVariable Long id) {
        return ResponseEntity.ok(appointmentService.forDoctor(id));
    }

    @PostMapping("/prescriptions")
    public ResponseEntity<Prescription> createPrescription(@Valid @RequestBody PrescriptionCreateRequest req) {
        return ResponseEntity.ok(prescriptionService.create(req.getDoctorId(), req.getPatientId(), req.getDiagnosis(), req.getMedicines(), req.getTests()));
    }

    @GetMapping("/{id}/prescriptions")
    public ResponseEntity<List<Prescription>> myPrescriptions(@PathVariable Long id) {
        return ResponseEntity.ok(prescriptionService.forDoctor(id));
    }
}


