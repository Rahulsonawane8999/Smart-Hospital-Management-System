package com.smarthealth.controller;

import com.smarthealth.dto.AssignDoctorRequest;
import com.smarthealth.dto.DoctorCreateRequest;
import com.smarthealth.model.Doctor;
import com.smarthealth.model.Patient;
import com.smarthealth.service.DoctorService;
import com.smarthealth.service.PatientService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final DoctorService doctorService;
    private final PatientService patientService;

    public AdminController(DoctorService doctorService, PatientService patientService) {
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    @PostMapping("/doctors")
    public ResponseEntity<Doctor> createDoctor(@Valid @RequestBody DoctorCreateRequest req) {
        Doctor d = doctorService.createDoctor(req.getFullName(), req.getEmail(), req.getPassword(), req.getSpecialization(), req.getLicenseNumber());
        return ResponseEntity.ok(d);
    }

    @GetMapping("/doctors")
    public ResponseEntity<List<Doctor>> listDoctors() {
        return ResponseEntity.ok(doctorService.findAll());
    }

    @PutMapping("/doctors/{id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable Long id, @RequestBody DoctorCreateRequest req) {
        Doctor d = doctorService.updateDoctor(id, req.getSpecialization(), req.getLicenseNumber(), req.getFullName());
        return ResponseEntity.ok(d);
    }

    @DeleteMapping("/doctors/{id}")
    public ResponseEntity<?> deleteDoctor(@PathVariable Long id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/patients")
    public ResponseEntity<List<Patient>> listPatients() { return ResponseEntity.ok(patientService.listAll()); }

    @GetMapping("/patients/pending")
    public ResponseEntity<List<Patient>> listPending() { return ResponseEntity.ok(patientService.listPendingApproval()); }

    @PostMapping("/patients/{id}/approve")
    public ResponseEntity<Patient> approve(@PathVariable Long id) { return ResponseEntity.ok(patientService.approvePatient(id)); }

    @PostMapping("/assign-doctor")
    public ResponseEntity<Patient> assignDoctor(@Valid @RequestBody AssignDoctorRequest req) {
        return ResponseEntity.ok(patientService.assignDoctor(req.getPatientId(), req.getDoctorId()));
    }

    @DeleteMapping("/patients/{id}")
    public ResponseEntity<?> deletePatient(@PathVariable Long id) {
        patientService.deletePatient(id);
        return ResponseEntity.noContent().build();
    }
}


