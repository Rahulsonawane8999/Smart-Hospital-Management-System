package com.smarthealth.controller;

import com.smarthealth.dto.LoginRequest;
import com.smarthealth.model.Role;
import com.smarthealth.model.User;
import com.smarthealth.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        String token = authService.login(request);
        return ResponseEntity.ok(Map.of("token", token));
    }

    @PostMapping("/seed-admin")
    public ResponseEntity<?> seedAdmin() {
        // Create default admin if not exists
        User user = authService.createUser("Admin User", "admin@smarthealth.com", "admin123", Role.ADMIN);
        return ResponseEntity.ok(Map.of("id", user.getId()));
    }
}


