package com.smarthealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartHospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
